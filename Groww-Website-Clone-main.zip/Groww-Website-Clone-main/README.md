# Groww-Website-Clone
Groww online Demat, Trading and Direct Mutual Fund Investment

Hii, Today I Start making Groww website using html css and Javascript 

This Website is Live on Netlify link is Below
 Link : https://groww-amit.netlify.app/
Index.html
    Home page
